import React, { useState } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import Topbar from "./Topbar";
import Sidebar from "./Sidebar";

import Dashboard from "./Dashboard";
import Generator from "./Generator";
import AIChat from "./AIChat";
import Settings from "./Settings";
import LandingPage from "./LandingPage";
import Profile from "./Profile";
import Plans from "./Plans";
import Connect from "./Connect";
import Login from "./Login";
import Signup from "./Signup";
import Projects from "./Projects";
import AIImage from "./AIImage";

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const toggleSidebar = () => setSidebarOpen(!sidebarOpen);

  return (
    <Router>
      <div className="flex h-screen overflow-hidden">
        {/* Sidebar */}
        {sidebarOpen && <Sidebar />}

        {/* Main Content */}
        <div className="flex-1 flex flex-col">
          <Topbar toggleSidebar={toggleSidebar} />

          <div className="flex-1 overflow-y-auto bg-black">
            <Routes>
              <Route path="/" element={<LandingPage />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/generator" element={<Generator />} />
              <Route path="/chatboard" element={<AIChat />} />
              <Route path="/settings" element={<Settings />} />
              <Route path="/plans" element={<Plans />} />
              <Route path="/profile" element={<Profile />} />
              <Route path="/connect" element={<Connect />} />
              <Route path="/login" element={<Login />} />
              <Route path="/signup" element={<Signup />} />
              <Route path="/projects" element={<Projects />} />
              <Route path="/ai-image" element={<AIImage />} />
              {/* Add more routes if needed */}
            </Routes>
          </div>
        </div>
      </div>
    </Router>
  );
}

export default App;
