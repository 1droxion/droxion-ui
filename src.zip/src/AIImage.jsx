import React, { useState, useEffect } from "react";
import axios from "axios";

function AIImage() {
  const [prompt, setPrompt] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(false);

  // Load history from localStorage
  useEffect(() => {
    const stored = JSON.parse(localStorage.getItem("droxion_image_history")) || [];
    setHistory(stored);
  }, []);

  const saveToHistory = (newItem) => {
    const updated = [newItem, ...history].slice(0, 10); // Limit to 10
    setHistory(updated);
    localStorage.setItem("droxion_image_history", JSON.stringify(updated));
  };

  const deleteFromHistory = (index) => {
    const updated = [...history];
    updated.splice(index, 1);
    setHistory(updated);
    localStorage.setItem("droxion_image_history", JSON.stringify(updated));
  };

  const generateImage = async () => {
    const user = JSON.parse(localStorage.getItem("droxion_user"));
    if (!user || user.credits < 1) {
      alert("❌ Not enough credits. Please upgrade your plan.");
      return;
    }

    if (!prompt.trim()) {
      alert("Please enter a prompt.");
      return;
    }

    setLoading(true);
    setImageUrl("");

    try {
      const response = await axios.post(
        "https://api.openai.com/v1/images/generations",
        {
          model: "dall-e-3",
          prompt: prompt,
          n: 1,
          size: "1024x1024"
        },
        {
          headers: {
            Authorization: `Bearer ${import.meta.env.VITE_OPENAI_API_KEY}`,
            "Content-Type": "application/json"
          }
        }
      );

      const url = response.data.data[0].url;
      setImageUrl(url);

      // Deduct credit
      user.credits -= 1;
      localStorage.setItem("droxion_user", JSON.stringify(user));

      // Save to history
      saveToHistory({ prompt, url, time: new Date().toISOString() });
    } catch (err) {
      console.error("❌ Error generating image:", err.response?.data || err.message);
      alert("Error generating image. Try again.");
    } finally {
      setLoading(false);
    }
  };

  const handlePresetClick = (style) => {
    setPrompt(`${style} of a futuristic city with neon lights`);
  };

  return (
    <div className="p-6 text-white max-w-5xl mx-auto">
      <h1 className="text-3xl font-bold text-center text-green-400 mb-6">🎨 AI Image Generator</h1>

      {/* Style Presets */}
      <div className="flex flex-wrap gap-3 justify-center mb-6">
        {["Pixel Art", "Anime Style", "3D Render", "Ghibli Style", "Cyberpunk", "Cartoon"].map((style) => (
          <button
            key={style}
            onClick={() => handlePresetClick(style)}
            className="bg-gray-800 hover:bg-gray-700 px-4 py-2 rounded text-sm border border-gray-600"
          >
            {style}
          </button>
        ))}
      </div>

      {/* Generated Image */}
      {imageUrl && (
        <div className="mb-8 flex flex-col items-center gap-4">
          <img
            src={imageUrl}
            alt="AI Output"
            className="max-w-full max-h-[500px] rounded-xl shadow-lg border border-gray-700"
          />
          <a
            href={imageUrl}
            download
            className="bg-purple-600 hover:bg-purple-700 px-5 py-2 rounded-lg text-white font-semibold transition"
          >
            ⬇️ Download Image
          </a>
        </div>
      )}

      {/* Prompt Input */}
      <div className="bg-[#1f2937] p-6 rounded-xl border border-gray-700 shadow-lg">
        <label className="block text-lg font-semibold mb-2">Prompt</label>
        <input
          type="text"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="Describe the image you want..."
          className="w-full p-3 rounded text-black mb-4 focus:outline-none focus:ring-2 focus:ring-green-500"
        />

        <button
          onClick={generateImage}
          disabled={loading}
          className="w-full bg-blue-500 hover:bg-blue-600 py-3 rounded-lg font-bold transition-all"
        >
          {loading ? "🎨 Generating..." : "🎨 Generate Image"}
        </button>
      </div>

      {/* Image History */}
      {history.length > 0 && (
        <div className="mt-10">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold">🕘 Recent Generations</h2>
            <button
              onClick={() => {
                setHistory([]);
                localStorage.removeItem("droxion_image_history");
              }}
              className="text-sm bg-red-600 hover:bg-red-700 text-white px-4 py-1 rounded transition"
            >
              🗑️ Clear All
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {history.map((item, i) => (
              <div key={i} className="bg-[#1a1a1a] p-4 rounded-lg border border-gray-700 shadow">
                <img
                  src={item.url}
                  alt="History"
                  className="w-full h-48 object-cover rounded mb-3"
                />
                <p className="text-sm text-gray-300 mb-2 truncate">📝 {item.prompt}</p>
                <div className="flex justify-between">
                  <a
                    href={item.url}
                    download
                    className="bg-gray-700 hover:bg-gray-600 text-sm px-3 py-1 rounded text-white"
                  >
                    ⬇️ Download
                  </a>
                  <button
                    onClick={() => deleteFromHistory(i)}
                    className="bg-red-600 hover:bg-red-700 text-sm px-3 py-1 rounded text-white"
                  >
                    🗑️ Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default AIImage;
