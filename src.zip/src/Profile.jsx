import React, { useState } from "react";

function Profile() {
  const stored = JSON.parse(localStorage.getItem("droxion_user")) || {
    username: "Dhruv",
    email: "",
    password: ""
  };

  const [username, setUsername] = useState(stored.username);
  const [email, setEmail] = useState(stored.email);
  const [password, setPassword] = useState(stored.password);
  const [showPassword, setShowPassword] = useState(false);
  const [avatar, setAvatar] = useState(null);

  const handleAvatarChange = (e) => {
    const file = e.target.files[0];
    setAvatar(URL.createObjectURL(file));
  };

  const handleSave = () => {
    const updatedUser = { username, email, password };
    localStorage.setItem("droxion_user", JSON.stringify(updatedUser));
    alert("✅ Profile saved (mock only)");
  };

  return (
    <div className="min-h-screen flex justify-center items-center text-white p-6">
      <div className="w-full max-w-xl bg-[#1f2937] border border-gray-700 shadow-2xl rounded-2xl p-8 space-y-6">
        <h1 className="text-3xl font-bold text-center text-primary">👤 My Profile</h1>

        {/* Avatar Upload */}
        <div className="flex flex-col items-center gap-3">
          <img
            src={
              avatar ||
              `https://ui-avatars.com/api/?name=${username}&background=0D8ABC&color=fff`
            }
            alt="Avatar"
            className="w-28 h-28 rounded-full object-cover shadow-md border-4 border-primary"
          />
          <label className="text-sm font-medium text-gray-300">Upload New Photo</label>
          <input
            type="file"
            accept="image/*"
            onChange={handleAvatarChange}
            className="text-xs bg-[#2d3748] px-3 py-1 rounded w-full text-center file:cursor-pointer"
          />
        </div>

        {/* Username */}
        <div>
          <label className="block text-sm font-medium mb-1">Username</label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="w-full bg-gray-800 p-2 rounded text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary"
          />
        </div>

        {/* Email */}
        <div>
          <label className="block text-sm font-medium mb-1">Email</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full bg-gray-800 p-2 rounded text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary"
          />
        </div>

        {/* Password */}
        <div>
          <label className="block text-sm font-medium mb-1">Password</label>
          <div className="relative">
            <input
              type={showPassword ? "text" : "password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-gray-800 p-2 pr-20 rounded text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-xs bg-gray-700 text-white px-2 py-1 rounded hover:bg-gray-600"
            >
              {showPassword ? "Hide" : "Show"}
            </button>
          </div>
        </div>

        {/* Save Button */}
        <div className="flex justify-center">
          <button
            onClick={handleSave}
            className="bg-green-500 hover:bg-green-600 px-6 py-2 rounded-lg font-semibold shadow-md transition-all duration-200 flex items-center gap-2"
          >
            💾 Save Profile
          </button>
        </div>
      </div>
    </div>
  );
}

export default Profile;
