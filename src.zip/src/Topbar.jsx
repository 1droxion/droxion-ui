import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";

function Topbar() {
  const [query, setQuery] = useState("");
  const [credits, setCredits] = useState(0);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const stored = localStorage.getItem("droxion_credits");
    if (stored) setCredits(Number(stored));
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    const q = query.toLowerCase();

    if (q.includes("generate") || q.includes("reel")) {
      navigate("/generator");
    } else if (q.includes("dashboard") || q.includes("credit")) {
      navigate("/dashboard");
    } else if (q.includes("chat") || q.includes("assistant")) {
      navigate("/chatboard");
    } else if (q.includes("setting") || q.includes("sound") || q.includes("toast")) {
      navigate("/settings");
    } else if (q.includes("plan") || q.includes("limit")) {
      navigate("/plans");
    } else if (q.includes("connect") || q.includes("upload")) {
      navigate("/connect");
    } else if (q.includes("style") || q.includes("image")) {
      navigate("/ai-image");
    } else {
      alert("❓ No matching page found for: " + query);
    }

    setQuery("");
  };

  // ❌ Pages where we don't want search bar
  const hideSearchRoutes = ["/settings", "/profile", "/login", "/signup", "/"];

  return (
    <div className="flex items-center justify-between bg-[#1f2937] px-4 py-2 border-b border-gray-800">
      {/* Conditionally Render Search */}
      {!hideSearchRoutes.includes(location.pathname) && (
        <form onSubmit={handleSearch} className="flex items-center bg-[#111827] rounded-lg px-4 py-2 w-full max-w-md">
          <span role="img" aria-label="search" className="text-gray-400 mr-2">🔍</span>
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search videos, topics, system help..."
            className="bg-transparent flex-1 text-white placeholder-gray-400 focus:outline-none"
          />
        </form>
      )}

      {/* Right: Credits + Settings icon */}
      <div className="flex items-center gap-4 ml-auto">
        <span className="text-sm text-green-400 font-semibold">
          🎯 {credits} credits
        </span>
        <div
          onClick={() => navigate("/settings")}
          className="w-8 h-8 bg-gray-700 rounded-full flex items-center justify-center text-white font-bold text-sm cursor-pointer hover:scale-105 transition"
        >
          ⚙️
        </div>
      </div>
    </div>
  );
}

export default Topbar;
