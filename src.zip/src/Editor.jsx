import React, { useState } from "react";

function Editor() {
  const [videos, setVideos] = useState([]);
  const [images, setImages] = useState([]);
  const [audios, setAudios] = useState([]);

  const handleFileChange = (e, type) => {
    const files = Array.from(e.target.files);
    if (type === "video") setVideos([...videos, ...files]);
    else if (type === "image") setImages([...images, ...files]);
    else if (type === "audio") setAudios([...audios, ...files]);
  };

  const handleSubmit = () => {
    alert("🚀 AI Editing coming soon...");
  };

  const FileCard = ({ icon, title, files, type }) => (
    <div className="bg-[#1e293b] p-5 rounded-xl border border-gray-700 shadow-lg">
      <h2 className="text-lg font-semibold mb-3">{icon} {title}</h2>
      <input
        type="file"
        accept={`${type}/*`}
        multiple
        onChange={(e) => handleFileChange(e, type)}
        className="w-full text-sm bg-gray-900 text-white border border-gray-600 p-2 rounded focus:outline-none"
      />
      {files.length > 0 && (
        <div className="mt-4 max-h-32 overflow-y-auto space-y-2 text-sm text-white">
          {files.map((f, i) => (
            <div key={i} className="bg-black/30 p-2 rounded flex items-center gap-2 truncate">
              <span className="text-xl">{icon}</span>
              <span className="truncate">{f.name}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  return (
    <div className="min-h-screen p-6 text-white">
      <h1 className="text-4xl font-extrabold text-white-400 mb-10 text-center">
        🎬 AI Upload Editor
      </h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <FileCard icon="🎥" title="Upload Videos" files={videos} type="video" />
        <FileCard icon="🖼️" title="Upload Images" files={images} type="image" />
        <FileCard icon="🎧" title="Upload Music" files={audios} type="audio" />
      </div>

      <div className="flex justify-center mt-12">
        <button
          onClick={handleSubmit}
          className="bg-blue-500 hover:bg-green-600 px-8 py-3 text-lg rounded-xl font-bold shadow-md transition-all duration-200 hover:shadow-green-500/50"
        >
          🚀 Submit for AI Editing
        </button>
      </div>
    </div>
  );
}

export default Editor;
