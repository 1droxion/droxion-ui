import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

function SearchBar() {
  const [query, setQuery] = useState("");
  const navigate = useNavigate();

  const handleSearch = (e) => {
    e.preventDefault();
    const q = query.toLowerCase();

    // Smart redirection logic
    if (q.includes("generate") || q.includes("reel")) {
      navigate("/generator");
    } else if (q.includes("dashboard") || q.includes("credit")) {
      navigate("/dashboard");
    } else if (q.includes("chat") || q.includes("assistant")) {
      navigate("/chatboard");
    } else if (q.includes("setting") || q.includes("sound") || q.includes("toast")) {
      navigate("/settings");
    } else if (q.includes("plan") || q.includes("limit")) {
      navigate("/plans");
    } else if (q.includes("connect") || q.includes("upload")) {
      navigate("/connect");
    } else if (q.includes("style") || q.includes("image")) {
      navigate("/ai-image");
    } else {
      alert("❓ No matching page found for: " + query);
    }

    setQuery("");
  };

  return (
    <form onSubmit={handleSearch} className="flex items-center bg-[#1f2937] rounded-lg px-4 py-2 w-full max-w-md">
      <span role="img" aria-label="search" className="text-gray-400 mr-2">🔍</span>
      <input
        type="text"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Search videos, topics, system help..."
        className="bg-transparent flex-1 text-white placeholder-gray-400 focus:outline-none"
      />
    </form>
  );
}

export default SearchBar;