import React, { useState } from "react";
import axios from "axios";

function AutoGenerator() {
  const [formData, setFormData] = useState({
    topic: "Motivation",
    language: "English",
    voice: "onyx",
    style: "Cinematic",
    length: "Medium",
    captions: "Word-by-Word",
    subtitlePosition: "Bottom",
    branding: "Yes",
    musicVolume: "Medium Volume",
    clipCount: 10,
    voiceSpeed: 1.0,
    fontPath: "NotoSans-Regular.ttf",
    manualScript: "no",
    userScript: "",
    mode: "Auto"
  });

  const [isLoading, setIsLoading] = useState(false);
  const [videoUrl, setVideoUrl] = useState("");
  const [videoReady, setVideoReady] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleAutoGenerate = async () => {
    const user = JSON.parse(localStorage.getItem("droxion_user"));
    if (!user || user.credits < 1) {
      alert("❌ Not enough credits. Please upgrade your plan.");
      return;
    }

    setIsLoading(true);
    setVideoReady(false);
    setVideoUrl("");

    try {
      const res = await axios.post("http://localhost:5000/generate", formData, {
        headers: {
          "Content-Type": "application/json",
        },
      });

      const { videoUrl } = res.data;
      setVideoUrl(videoUrl);
      setVideoReady(true);

      user.credits -= 1;
      localStorage.setItem("droxion_user", JSON.stringify(user));
    } catch (err) {
      console.error("❌ API ERROR:", err.response?.data || err.message);
      alert("❌ Generation failed: " + (err.response?.data?.message || err.message));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center p-6">
      <h1 className="text-2xl font-bold text-purple-500 mb-6">⚡ Auto Video Generator</h1>

      {/* Topic Selector */}
      <div className="mb-4 w-full max-w-sm">
        <label className="block text-sm font-medium mb-1">🎯 Topic:</label>
        <select
          name="topic"
          value={formData.topic}
          onChange={handleChange}
          className="w-full p-2 rounded text-black"
        >
          <option>Motivation</option>
          <option>Success</option>
          <option>Love</option>
          <option>Business</option>
          <option>Health</option>
        </select>
      </div>

      <button
        onClick={handleAutoGenerate}
        className="bg-purple-600 text-white px-6 py-2 rounded hover:bg-purple-700"
      >
        {isLoading ? "⚙️ Generating..." : "⚡ Auto Generate"}
      </button>

      {videoReady && videoUrl && (
        <div className="mt-8 text-center">
          <video src={videoUrl} controls className="w-full max-w-md mb-4" />
          <div>
            <a
              href={videoUrl}
              download
              className="inline-block bg-blue-500 px-4 py-2 rounded mr-4"
            >⬇️ Download</a>
            <a
              href={videoUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-purple-500 px-4 py-2 rounded"
            >▶️ Watch Fullscreen</a>
          </div>
        </div>
      )}
    </div>
  );
}

export default AutoGenerator;
