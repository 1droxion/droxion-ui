import React from "react";
import { useNavigate } from "react-router-dom";

function LandingPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-black text-white">
      {/* HERO */}
      <div className="text-center px-6 py-20">
        <h1 className="text-4xl md:text-5xl font-extrabold text-purple-500 mb-4">
          Welcome to Droxion™
        </h1>
        <p className="text-lg md:text-xl text-gray-300 max-w-2xl mx-auto">
          Your all-in-one AI system for generating powerful reels, voiceovers, and dynamic content — fully automated.
        </p>
        <div className="mt-8 flex justify-center gap-4">
          <button
            onClick={() => navigate("/login")}
            className="px-6 py-3 bg-green-500 hover:bg-green-600 rounded-xl font-bold transition"
          >
            Get Started
          </button>
          <button
            onClick={() => navigate("/generator")}
            className="px-6 py-3 bg-gray-700 hover:bg-gray-600 rounded-xl font-bold"
          >
            Try Generator
          </button>
        </div>
      </div>

      {/* FEATURES */}
      <div className="bg-[#111827] py-14 px-6">
        <h2 className="text-3xl font-bold text-center mb-10 text-white">
          💡 What Droxion Can Do
        </h2>

        <div className="grid gap-8 md:grid-cols-2 max-w-4xl mx-auto">
          <Feature title="🎬 AI Reel Generator" desc="Generate cinematic or emotional videos using AI with just a topic or script." />
          <Feature title="🗣️ Voiceover Engine" desc="Choose from natural-sounding AI voices in English, Hindi, Gujarati and more." />
          <Feature title="🎵 Background Music & Subtitles" desc="Auto-add royalty-free music and dynamic subtitles to your video." />
          <Feature title="🚀 Auto Upload & Scheduling" desc="Coming soon: auto-post to Instagram, YouTube, Facebook with one click." />
        </div>
      </div>

      {/* FOOTER */}
      <footer className="text-center text-gray-400 py-6 text-sm border-t border-gray-700">
        © {new Date().getFullYear()} Droxion™. All rights reserved.
      </footer>
    </div>
  );
}

function Feature({ title, desc }) {
  return (
    <div className="bg-[#1f2937] p-6 rounded-xl shadow-lg border border-gray-700 hover:shadow-xl transition">
      <h3 className="text-xl font-semibold text-purple-300 mb-2">{title}</h3>
      <p className="text-gray-300">{desc}</p>
    </div>
  );
}

export default LandingPage;
