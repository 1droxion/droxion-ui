import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

function SearchBar() {
  const [query, setQuery] = useState("");
  const navigate = useNavigate();

  const handleSearch = (e) => {
    e.preventDefault();
    const q = query.toLowerCase();

    // Smart navigation based on keywords
    if (q.includes("generate") || q.includes("reel")) {
      navigate("/generator");
    } else if (q.includes("dashboard") || q.includes("credit")) {
      navigate("/dashboard");
    } else if (q.includes("chat") || q.includes("assistant")) {
      navigate("/chatboard");
    } else if (q.includes("setting") || q.includes("sound") || q.includes("toast")) {
      navigate("/settings");
    } else if (q.includes("plan") || q.includes("limit")) {
      navigate("/plans");
    } else if (q.includes("profile")) {
      navigate("/profile");
    } else {
      alert("No matching page found.");
    }
  };

  return (
    <form onSubmit={handleSearch} className="flex items-center gap-2">
      <input
        type="text"
        placeholder="Search pages..."
        className="px-3 py-1 rounded bg-gray-800 text-white"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />
      <button
        type="submit"
        className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded"
      >
        🔍
      </button>
    </form>
  );
}

export default SearchBar;
